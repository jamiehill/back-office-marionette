define(function (require) {
    var Service = require('common/framework/service/Backbone.Service');
    return Service.extend({

    });
});
/**
 * Created by Jamie on 22/09/2014.
 */
define([
        'marionette'
    ],
    function (Marionette) {
        return Marionette.Controller.extend({


            /**
             *
             */
            initialize: function(options){
//                thismodel = options.model;
            }
        });
    });
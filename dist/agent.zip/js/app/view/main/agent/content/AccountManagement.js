define([
    'marionette',
    'text!app/view/main/agent/content/management/AccountManagement.tpl.html'
],
function (Marionette, tpl) {
    return Marionette.ItemView.extend({
        dependencies: 'agentModel, apiService, commands',


        id: 'tab3',
        className: 'form-body ui-tabs-panel ui-widget-content ui-corner-bottom',
        template: _.template(tpl),
        tagName: "li",

        events: {
            'click .fa.fa-pencil' : 'onEditClick'
        },


        /**
         *
         */
        initialize: function() {
            this.listenTo(this.model, 'change:accounts', this.onModelChange);
        },


        /**
         *
         */
        onModelChange: function(){
            this.render();
        },


        onEditClick: function(event) {
            var userId = $(event.currentTarget).attr('userId'),
                tableRow = $(event.currentTarget).closest('.table-row.management'),
                children = tableRow.children();

            _.each(children, function(child) {
                if ($(child).attr('contenteditable'))
                    $(child).addClass('editable').attr('contenteditable', true);
            });
        }
    });
});
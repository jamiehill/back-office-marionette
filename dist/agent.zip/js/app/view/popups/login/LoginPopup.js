define(['backbone', 'modal', 'ctx', 'app/model/models/session/Login', 'text!app/view/popups/login/LoginPopup.tpl.html'],
function (Backbone, Modal, ctx, Login, tpl) {
    return Backbone.Modal.extend({
        template: _.template(tpl),


        dependencies: 'apiService, sessionModel, commands',
        submitEl: '.loginSubmit',
        clearEl: '.loginClear',
        clickOutsideEnabled: false,
        regionEnabled: true,


        events: {
            'click .clear': 'clear'
        },



        /**
         *
         */
        initialize: function(){
            _.bindAll(this, 'loginSuccess', 'loginFailure');
        },


        /**
         * Focus the username input
         */
        onOpened: function(){
            this.clear();
        },


        /**
         * Check both fields have been populated
         */
        beforeSubmit: function(e){
            var userInput = $('#userInput'),
                passInput = $('#passInput');
            this.user = userInput.val();
            this.pass = passInput.val();
            return $.trim(this.user).length > 0 && $.trim(this.pass).length > 0;
        },


        /**
         *
         */
        submit: function(e){
            this.commands.execute('command:login', this.user, this.pass)
                .done(this.loginSuccess)
                .fail(this.loginFailure);
        },


        /**
         *
         */
        clear: function(e){
            $('input[name=username]').val('');
            $('input[name=password]').val('');
            $('#feedback').html('');
            setTimeout(function(){
                $('input[name=username]').focus();
            }, 50);
        },



        /**
         * Login successful.  Close popup
         * @param e
         */
        loginSuccess: function(data, textStatus, jqXHR){
            var args = arguments;
            this.close();
        },


        /**
         * Login failed - show some feedback
         * @param e
         */
        loginFailure: function(jqXHR, textStatus, errorThrown){
            var args = arguments;
            var error = args[0].Error.value,
                feedback = $(this.el).find('#feedback');
            feedback.html(error);
        }
    });
});
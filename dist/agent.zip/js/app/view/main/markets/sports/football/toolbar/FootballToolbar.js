define([

    'backbone',
    'app/view/main/markets/sports/BaseEventToolbar'
],

function (Backbone, BaseEventToolbar, template) {
    'use strict';


    var FootballToolbar = BaseEventToolbar.extend({});
    return FootballToolbar;
});

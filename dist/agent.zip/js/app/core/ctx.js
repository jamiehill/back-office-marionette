define(['di'], function(di) {
    return di.createContext();
});
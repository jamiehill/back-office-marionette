define(['marionette'],
function (Marionette) {

    return Marionette.LayoutView.extend({
        onShow: function() {
        }
    });
});
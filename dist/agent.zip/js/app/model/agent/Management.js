define(['backbone'],
function (Backbone) {
    return Backbone.Model.extend({

        name: 'MANAGEMENT',
        title: 'Account Management',
        clazz: 'accountManagement',

        defaults: {
            accounts: null
        }
    });
});
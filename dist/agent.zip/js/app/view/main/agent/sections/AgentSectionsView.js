/**
 * Created by Jamie on 22/09/2014.
 */
define([
    'marionette',
    'backbone',
    'app/view/main/agent/sections/AgentSectionView',
    'common/util/CollectionUtil',
    'text!app/view/main/agent/AgentView.tpl.html'
],

function (Marionette, Backbone, AgentSectionView, collection, tpl) {
    return Marionette.CollectionView.extend({

    });
});